package clock;
// fonctionnement du bouton Heure

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

class ActionBoutonHeure extends AbstractAction {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7421744113938291016L;
	private Horloge hologe = new Horloge();
	public ActionBoutonHeure(String titre) {
		super(titre);
		
	}

	public void actionPerformed(ActionEvent arg0) {
		try {
			Horloge.heure = Integer.parseInt(Horloge.Heure_TextField.getText());

			if (Horloge.heure < hologe.Heure_MIN || Horloge.heure > hologe.Heure_MAX)
				throw new NumberFormatException();

		} catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(null,
					"Veuillez saisir une valeur d'heure entre " + Horloge.Heure_MIN + " et " + Horloge.Heure_MAX + " !",
					"Erreur de saisie", JOptionPane.ERROR_MESSAGE);
			return;
		}

		try {
			Horloge.minute = Integer.parseInt(Horloge.Minute_TextField.getText());
			System.out.println(Horloge.minute);
			if (Horloge.minute < Horloge.Minute_MIN || Horloge.minute > Horloge.Minute_MAX)
				throw new NumberFormatException();

		} catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(null,
					"Veuillez saisir une valeur de minute entre " + Horloge.Minute_MIN + " et " + Horloge.Minute_MAX + " !",
					"Erreur de saisie", JOptionPane.ERROR_MESSAGE);
			return;
		}

		try {
			Horloge.seconde = Integer.parseInt(Horloge.Seconde_TextField.getText());
			if (Horloge.seconde < Horloge.Seconde_MIN || Horloge.seconde > Horloge.Seconde_MAX)
				throw new NumberFormatException();

		} catch (NumberFormatException e) {
			JOptionPane.showMessageDialog(null,
					"Veuillez saisir une valeur de seconde entre " + Horloge.Seconde_MIN + " et " + Horloge.Seconde_MAX + " !",
					"Erreur de saisie", JOptionPane.ERROR_MESSAGE);
			return;
		}
		Horloge.l = new JLabel("This is a JInternal Frame  ");

		// create a panel
		JPanel p = new JPanel();

		// add label and button to panel
		p.add(Horloge.l);

		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}