package clock;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.time.LocalDateTime;

import javax.swing.JComponent;

public class JClock extends JComponent {
	private static final long serialVersionUID = 1L;
	private static final String DATE_FORMATTER = "yyyy-MM-dd HH:mm:ss";

	private final CoolPaint paint;
	private final Object lock;
	private Thread updater;

	Horloge h = new Horloge();

	public JClock(CoolPaint paint) {
		this.paint = paint;
		this.lock = new Object();
	}

	private void runClock() {
		int lastTime = -1;
		try {
			while (isRunning()) {
				Thread.sleep(10);
				int t = time();
				if (t != lastTime) {
					lastTime = t;
					repaint();
				}
			}
		} catch (InterruptedException e) {
			// Do nothing, the thread will die naturally.
		}
	}
	
	
	private void init() {
		
	}

	private int time() {
		
		int s = (Horloge.heure*3600)+(Horloge.minute*60)+Horloge.seconde;
		
		return s;

	}

	private boolean isRunning() {
		synchronized (lock) {
			return updater == Thread.currentThread();
		}
	}

	public void start() {
		synchronized (lock) {
			if (updater != null)
				return;
			updater = new Thread(this::runClock);
			updater.start();
		}
	}

	public void stop() {
		synchronized (lock) {
			updater = null;
		}
	}

	@Override
	public void paintComponent(Graphics g) {
		paint.paintClock(getWidth(), getHeight(), time(), (Graphics2D) g);
	}
}