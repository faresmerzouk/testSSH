package clock;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.border.LineBorder;

public class Horloge extends JFrame {

	private static final long serialVersionUID = -217919855465215916L;
	static JTextField Heure_TextField;
	static JTextField Minute_TextField;
	public static JTextField Seconde_TextField;
	Calendar calendar = Calendar.getInstance();
	private JPanel panel;
	private JPanel p;
	JLabel TimeLabel;
	static JLabel l;
	public static int heure = 0;
	public static int minute = 0;
	public static int seconde = 0;
	String time;
	SimpleDateFormat TimeFormat;

	static final int Heure_MIN = 0;
	static final int Heure_MAX = 23;

	static final int Minute_MIN = 0;
	static final int Minute_MAX = 59;

	static final int Seconde_MIN = 0;
	static final int Seconde_MAX = 59;

	public Horloge() {
		// initialize();
	}

	public void initialize() {

		final JClock clock = new JClock(new CoolPaint());
		this.add(clock);
		this.setBounds(20, 20, 600, 500);
		this.setVisible(true);
		clock.start();

		this.setResizable(false);
		this.setTitle("Horloge Num�rique et Analogique");
		this.setBounds(100, 100, 650, 550);
		// 100, 100, 640, 550 Origin
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.getContentPane().setLayout(null);

		// pour centr� notre fenetre
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		//
		panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(152, 250, 0)));
		panel.setBounds(10, 10, 500, 500);
		this.getContentPane().add(panel);

		// champs d'heure
		Heure_TextField = new JTextField();
		Heure_TextField.setBounds(516, 10, 46, 25);
		this.getContentPane().add(Heure_TextField);
		Heure_TextField.setColumns(10);

		JLabel lblHeure = new JLabel("Heure");
		lblHeure.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblHeure.setBounds(565, 15, 61, 14);
		getContentPane().add(lblHeure);

		// champs minute
		Minute_TextField = new JTextField();
		Minute_TextField.setBounds(516, 50, 46, 25);
		this.getContentPane().add(Minute_TextField);
		Minute_TextField.setColumns(10);

		JLabel lblMinute = new JLabel("Minute");
		lblMinute.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblMinute.setBounds(565, 50, 61, 14);
		getContentPane().add(lblMinute);

		// champs Seconde
		Seconde_TextField = new JTextField();
		Seconde_TextField.setBounds(516, 90, 46, 25);
		this.getContentPane().add(Seconde_TextField);
		Seconde_TextField.setColumns(10);

		JLabel lblSeconde = new JLabel("Seconde");
		lblSeconde.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblSeconde.setBounds(565, 90, 61, 14);
		getContentPane().add(lblSeconde);

		JButton btnExit = new JButton(new ActionBoutonExit("Exit", this));
		btnExit.setBounds(516, 487, 108, 23);
		this.getContentPane().add(btnExit);

		JButton btnNewButton = new JButton(new ActionBoutonHeure("Valider"));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});

		btnNewButton.setBounds(516, 150, 108, 23);
		this.getContentPane().add(btnNewButton);
	}

}
