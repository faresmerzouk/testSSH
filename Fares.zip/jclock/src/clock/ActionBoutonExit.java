package clock;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

class ActionBoutonExit extends AbstractAction {
	/**
	 * 
	 */
	// private static final long serialVersionUID = -7035755195998952784L;
	private Horloge window;

	public ActionBoutonExit(String titre, Horloge window) {
		super(titre);
		this.window = window;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		window.dispose();
	}
}